# Lúmen — câmera com LUTs e presets em tempo real

App Android (.apk) de câmera com **55 câmeras/presets** (lista do `cameras.csv`), cada uma com seus **LUTs** e efeitos,
com visualização ao vivo no visor e em todas as miniaturas (carrossel de câmeras e faixa de LUTs).

## Como gerar o APK (escolha um)

**A) GitHub Actions (sem instalar nada)**
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (incluindo `.github/`).
2. Aba **Actions** → **Build APK** → **Run workflow**.
3. Ao terminar, baixe o artefato `lumen-camera-apk` → `app-debug.apk` e instale no celular
   (permita "instalar apps desconhecidos").

**B) Android Studio**: *File → Open* nesta pasta → *Build → Build APK(s)*.

**C) Linha de comando** (JDK 17 + Android SDK + Gradle 8.7): `gradle assembleDebug`
→ `app/build/outputs/apk/debug/app-debug.apk`.

## Como funciona
- `app/src/main/assets/index.html`: toda a interface e o pipeline (WebGL): captura → LUT 3D trilinear
  (32³, mesma matemática descrita no dossiê: floor/ceil/mix) → fade/halation/bloom → lente (fisheye, prisma,
  estrelas, ND, flash) → leaks/vinheta/scanline/poeira/grão → molduras e carimbo de data.
- `MainActivity.java`: casca nativa mínima (WebView em contexto seguro, permissões de câmera/microfone,
  salva fotos em `Pictures/Lumen` e vídeos em `Movies/Lumen`).
- Android 10+ (minSdk 29).

## Uso
- Toque numa câmera do carrossel; troque a categoria nas abas (inclui VÍDEO e LENTES).
- A faixa **LUTs** mostra as variações de LUT da câmera ao vivo; o slider ajusta a intensidade.
- **Segure o visor** para ver o original. **FX** liga/desliga efeitos e molduras (fica só o LUT).
- Câmeras de vídeo: o botão vira gravar (com áudio, se permitido).
- Lentes (ND, Fisheye, Fisheye Wide, Flash C, Stars, Prism) se combinam com qualquer câmera.

## Limites de fidelidade (importante)
Os arquivos enviados descrevem **estrutura e nomes** (câmeras, kernels, campos, LUTs, recursos), mas **não contêm**
as LUTs reais, os PNG/JPG de molduras/grãos, a fonte VCR nem os valores numéricos de cada receita.
Por isso: as LUTs são geradas proceduralmente por receita (variações Padrão/Color/Light etc.), molduras e grãos
são desenhados por código, e todos os valores são **estimativas**. A associação de alguns LUTs (ex.: `nmf`, `ou`)
a câmeras específicas também é suposição. Para ficar idêntico seria preciso ter os assets originais.
Nome e ícone são próprios (sem marca de terceiros).
